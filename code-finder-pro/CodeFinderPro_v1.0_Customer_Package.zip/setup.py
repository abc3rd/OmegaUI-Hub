#!/usr/bin/env python3
"""
Code Finder Pro - Setup & Installation Script
Copyright © 2026 Omega UI, LLC / Cloud Connect

This script:
1. Checks Python version
2. Installs required dependencies
3. Verifies installation
4. Optionally runs the application
"""

import sys
import subprocess
import os
from pathlib import Path

def print_header():
    """Print setup header"""
    print("="*70)
    print("Code Finder Pro - Setup & Installation")
    print("© 2026 Omega UI, LLC / Cloud Connect")
    print("="*70)
    print()

def check_python_version():
    """Verify Python version is 3.7 or higher"""
    print("Checking Python version...")
    
    version = sys.version_info
    print(f"  Found: Python {version.major}.{version.minor}.{version.micro}")
    
    if version.major < 3 or (version.major == 3 and version.minor < 7):
        print("  ✗ ERROR: Python 3.7 or higher required")
        print("  Please upgrade Python: https://www.python.org/downloads/")
        return False
    
    print("  ✓ Python version OK")
    return True

def check_tkinter():
    """Check if tkinter is available"""
    print("\nChecking for tkinter...")
    
    try:
        import tkinter
        print("  ✓ tkinter is available")
        return True
    except ImportError:
        print("  ✗ ERROR: tkinter not found")
        print("  Please install tkinter:")
        print("    Ubuntu/Debian: sudo apt-get install python3-tk")
        print("    Fedora: sudo dnf install python3-tkinter")
        print("    macOS: tkinter should be included with Python")
        print("    Windows: tkinter should be included with Python")
        return False

def install_dependencies():
    """Install required Python packages"""
    print("\nInstalling dependencies...")
    
    try:
        # Upgrade pip first
        print("  Upgrading pip...")
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", "--upgrade", "pip"
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        
        # Install beautifulsoup4
        print("  Installing beautifulsoup4...")
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", "beautifulsoup4"
        ])
        
        print("  ✓ Dependencies installed successfully")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"  ✗ ERROR: Failed to install dependencies: {e}")
        return False

def verify_installation():
    """Verify all components are working"""
    print("\nVerifying installation...")
    
    try:
        # Test imports
        import tkinter
        from bs4 import BeautifulSoup
        
        print("  ✓ All components verified")
        return True
        
    except ImportError as e:
        print(f"  ✗ ERROR: Verification failed: {e}")
        return False

def create_desktop_shortcut():
    """Create desktop shortcut (optional)"""
    print("\nDesktop shortcut creation...")
    
    response = input("  Create desktop shortcut? (y/n): ").lower().strip()
    
    if response != 'y':
        print("  Skipped")
        return
    
    # This is platform-specific and simplified
    print("  Note: Manual shortcut creation recommended")
    print(f"  Target: {sys.executable}")
    print(f"  Arguments: {os.path.abspath('code_finder_pro.py')}")

def run_application():
    """Ask if user wants to run the application now"""
    print("\n" + "="*70)
    print("Setup Complete!")
    print("="*70)
    print()
    
    response = input("Launch Code Finder Pro now? (y/n): ").lower().strip()
    
    if response == 'y':
        print("\nLaunching Code Finder Pro...")
        try:
            import code_finder_pro
            code_finder_pro.main()
        except Exception as e:
            print(f"Error launching application: {e}")
            print("\nYou can run it manually with:")
            print(f"  python code_finder_pro.py")
    else:
        print("\nYou can run Code Finder Pro anytime with:")
        print(f"  python code_finder_pro.py")
        print("\nOr build a standalone executable:")
        print(f"  python build_executable.py")

def main():
    """Main setup routine"""
    print_header()
    
    # Check Python version
    if not check_python_version():
        sys.exit(1)
    
    # Check tkinter
    if not check_tkinter():
        print("\nSetup cannot continue without tkinter.")
        print("Please install tkinter and run setup again.")
        sys.exit(1)
    
    # Install dependencies
    if not install_dependencies():
        print("\nSetup failed during dependency installation.")
        sys.exit(1)
    
    # Verify installation
    if not verify_installation():
        print("\nSetup completed but verification failed.")
        print("The application may not work correctly.")
        sys.exit(1)
    
    # Optional: Create shortcut
    create_desktop_shortcut()
    
    # Done!
    run_application()
    
    print("\n" + "="*70)
    print("Thank you for choosing Code Finder Pro!")
    print("For support: info@omegaui.com | +1 239-347-6030")
    print("="*70 + "\n")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nSetup cancelled by user.")
        sys.exit(0)
    except Exception as e:
        print(f"\n\nUnexpected error during setup: {e}")
        print("Please contact support: info@omegaui.com")
        sys.exit(1)
