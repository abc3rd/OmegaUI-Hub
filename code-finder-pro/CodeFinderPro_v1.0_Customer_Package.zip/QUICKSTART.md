# Code Finder Pro - Quick Start Guide

**Get up and running in 5 minutes!**

---

## 📦 Installation

### Option 1: Run with Python (Recommended for developers)

```bash
# Download/clone the application
cd code_finder_pro

# Run directly (dependencies auto-install)
python code_finder_pro.py
```

### Option 2: Standalone Executable (No Python needed)

1. Download `CodeFinderPro.exe` (Windows) or `CodeFinderPro` (Mac/Linux)
2. Double-click to run
3. That's it!

---

## 🎯 Your First Search in 60 Seconds

### Step 1: Select Folders (15 seconds)

1. Click **"Browse"** next to **Search Root**
2. Choose the folder with your code (e.g., `C:\Projects\MyApp`)
3. Click **"Browse"** next to **Output Folder**
4. Choose where to save results (e.g., `C:\Users\YourName\Desktop\Results`)

### Step 2: Choose File Types (15 seconds)

Check the boxes for the languages you use:
- ✅ Python
- ✅ JavaScript
- ✅ CSS/SCSS
- ✅ HTML

**Pro tip:** Click **"Select All"** to search everything!

### Step 3: Enter Keywords (15 seconds)

Type what you're looking for, separated by commas:

```
authentication, login, user, session
```

**Or leave blank** to find all files of your selected types.

### Step 4: Run! (15 seconds)

1. Click the big green **"🔍 Run Search"** button
2. Watch the progress in the status bar
3. Wait for completion (usually 10-60 seconds)

---

## 🎨 Understanding Your Results

After search completes, you'll see:

```
Search complete! Found 47 matching files out of 1,234 scanned.
```

### Preview Your Results

Click **"👁 Preview Results"** to see:

- **Left pane**: List of files ranked by score
- **Right pane**: Detailed information about selected file

**What the scores mean:**
- **10-20**: Minimal match (1-2 keywords)
- **30-50**: Good match (multiple keywords + patterns)
- **50+**: Excellent match (project files, many keywords)

### Open Files Directly

From the preview window:
- Click **"📂 Open File"** to edit in your editor
- Click **"📁 Open Folder"** to see in file explorer

---

## 💾 Export Your Results

Click **"💾 Export"** and choose format:

- **JSON** - For programmatic use, data analysis
- **CSV** - For Excel, Google Sheets
- **TXT** - For reports, documentation

All formats include:
- File paths and names
- Scores and rankings
- Matched keywords
- Content snippets

---

## ⚙️ Pro Tips

### Speed Up Searches

Go to **Advanced** tab:
1. Set **Max File Size** to 5 MB (skip huge files)
2. Add to **Exclude Directories**: `node_modules, .git, dist, build`

### Find Specific Patterns

Enable **"Use Regular Expressions"** for advanced searches:

```
# Find email addresses
\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b

# Find TODO comments
TODO|FIXME|HACK

# Find function definitions
def\s+\w+\s*\(|function\s+\w+\s*\(
```

### Use Search History

1. Go to **History** tab
2. See all your previous searches
3. Click **"Load Selected"** to reuse parameters
4. No need to set up searches again!

### Adjust Score Threshold

- **Default (10)**: Broad results, might include many files
- **Medium (30)**: Balanced results, good for most searches
- **High (50+)**: Very precise, only best matches

---

## 🆘 Common Questions

**Q: Why are my results empty?**
- Lower the minimum score (try 5 or 10)
- Check that file types are selected
- Make sure keywords are spelled correctly
- Try searching without keywords first

**Q: Search is taking forever**
- Add more folders to exclude (node_modules, etc.)
- Reduce max file size
- Select fewer file types

**Q: Can't find a specific file**
- Make sure its extension is in a selected file type
- Try searching the filename directly
- Check if it's in an excluded directory

**Q: How do I search my entire computer?**
- Set Search Root to `C:\` (Windows) or `/` (Mac/Linux)
- **Warning**: This will take a LONG time!
- Better: Search specific project folders

---

## 🎓 Next Steps

Now that you've completed your first search:

1. **Read the full README.md** for advanced features
2. **Explore the Advanced tab** for more options
3. **Check out History** to reuse successful searches
4. **Try exporting** in different formats
5. **Experiment with regex** for powerful patterns

---

## 📞 Need Help?

- **Email**: info@omegaui.com
- **Phone**: +1 239-347-6030
- **Web**: https://www.omegaui.com

Or press **F1** in the app for built-in help!

---

## 🎉 You're Ready!

You now know enough to be productive with Code Finder Pro.

**Happy searching!** 🚀

---

© 2026 Omega UI, LLC / Cloud Connect
