#!/usr/bin/env python3
"""
Code Finder Pro - Professional Code Search and Analysis Tool
Copyright (c) 2026 Omega UI, LLC / Cloud Connect
Version: 1.0.0
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import threading
import queue
import os
import json
import csv
import re
from datetime import datetime
from pathlib import Path
import webbrowser
from typing import List, Dict, Optional, Tuple
import subprocess
import platform

# Auto-install beautifulsoup4 if not available
try:
    from bs4 import BeautifulSoup
except ImportError:
    import subprocess
    import sys
    subprocess.check_call([sys.executable, "-m", "pip", "install", "beautifulsoup4"])
    from bs4 import BeautifulSoup


# ==================== CONFIGURATION ====================
class Config:
    """Application configuration and constants"""
    
    # Application Info
    APP_NAME = "Code Finder Pro"
    VERSION = "1.0.0"
    COPYRIGHT = "© 2026 Omega UI, LLC / Cloud Connect"
    
    # Brand Colors (Omega UI)
    COLOR_GREEN = "#4bce2a"
    COLOR_BLUE = "#2699fe"
    COLOR_ORANGE = "#c4653a"
    COLOR_MAGENTA = "#ea00ea"
    COLOR_DARK_GRAY = "#3c3c3c"
    COLOR_LIGHT_PURPLE = "#f4eefe"
    
    # File Types
    FILE_TYPES = {
        "Python": [".py", ".pyw"],
        "JavaScript": [".js", ".jsx", ".mjs", ".cjs"],
        "Dart/Flutter": [".dart"],
        "Kotlin": [".kt", ".kts"],
        "Java": [".java"],
        "PHP": [".php"],
        "C/C++": [".cpp", ".c", ".h", ".hpp"],
        "CSS/SCSS": [".css", ".scss", ".sass", ".less"],
        "HTML": [".html", ".htm"],
        "JSON": [".json"],
        "YAML": [".yaml", ".yml"],
        "XML": [".xml"],
        "Text": [".txt", ".md", ".log"],
        "Config": [".env", ".config", ".ini", ".conf"],
        "AI Models": [".h5", ".pt", ".model", ".pkl"],
    }
    
    # Scoring Weights
    SCORE_KEYWORD_MATCH = 10
    SCORE_POSITIVE_PATTERN = 3
    SCORE_NEGATIVE_PATTERN = -5
    SCORE_PROJECT_FILE = 20
    
    # Positive Patterns
    POSITIVE_PATTERNS = [
        "function", "const", "class", "def", "async", "await",
        "export", "import", "module", "component", "widget"
    ]
    
    # Negative Patterns
    NEGATIVE_PATTERNS = [
        "error", "todo", "fixme", "broken", "deprecated",
        "hack", "workaround", "temporary"
    ]
    
    # Project Files
    PROJECT_FILES = [
        "package.json", "pubspec.yaml", "requirements.txt",
        "Gemfile", "pom.xml", "build.gradle", "composer.json"
    ]
    
    # Default Paths
    DEFAULT_OUTPUT_DIR = str(Path.home() / "CodeFinderResults")
    CONFIG_DIR = str(Path.home() / ".codefinderpro")
    CONFIG_FILE = str(Path(CONFIG_DIR) / "config.json")
    HISTORY_FILE = str(Path(CONFIG_DIR) / "history.json")
    
    # Search Settings
    MAX_HISTORY_ITEMS = 50
    MAX_SNIPPET_LENGTH = 500
    MAX_PREVIEW_CONTENT = 5000


# ==================== UTILITY FUNCTIONS ====================
def ensure_config_dir():
    """Create config directory if it doesn't exist"""
    os.makedirs(Config.CONFIG_DIR, exist_ok=True)


def extract_content(filepath: str) -> Optional[str]:
    """
    Extract text content from various file types.
    
    Args:
        filepath: Path to the file
        
    Returns:
        Extracted text content or None if extraction fails
    """
    try:
        ext = os.path.splitext(filepath)[1].lower()
        
        # Binary files - skip
        binary_extensions = [
            '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.ico', '.svg',
            '.mp4', '.avi', '.mov', '.mp3', '.wav', '.pdf',
            '.zip', '.tar', '.gz', '.exe', '.dll', '.so'
        ]
        if ext in binary_extensions:
            return None
        
        # Text-based files
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read(Config.MAX_PREVIEW_CONTENT)
            
        # HTML/XML - extract text
        if ext in ['.html', '.htm', '.xml']:
            soup = BeautifulSoup(content, 'html.parser')
            return soup.get_text()
            
        return content
        
    except Exception as e:
        return None


def score_file(content: Optional[str], keywords: List[str], filepath: str, 
               use_regex: bool = False) -> int:
    """
    Score a file based on content, keywords, and patterns.
    
    Args:
        content: File content to score
        keywords: List of keywords to search for
        filepath: Path to the file
        use_regex: Whether to use regex matching
        
    Returns:
        Score value (higher is more relevant)
    """
    score = 0
    
    if content is None:
        return score
    
    content_lower = content.lower()
    
    # Score keywords
    for keyword in keywords:
        if use_regex:
            try:
                if re.search(keyword, content, re.IGNORECASE):
                    score += Config.SCORE_KEYWORD_MATCH
            except re.error:
                # Invalid regex, fall back to literal
                if keyword.lower() in content_lower:
                    score += Config.SCORE_KEYWORD_MATCH
        else:
            if keyword.lower() in content_lower:
                score += Config.SCORE_KEYWORD_MATCH
    
    # Score positive patterns
    for pattern in Config.POSITIVE_PATTERNS:
        if pattern in content_lower:
            score += Config.SCORE_POSITIVE_PATTERN
    
    # Score negative patterns
    for pattern in Config.NEGATIVE_PATTERNS:
        if pattern in content_lower:
            score += Config.SCORE_NEGATIVE_PATTERN
    
    # Bonus for project files
    filename = os.path.basename(filepath)
    if filename in Config.PROJECT_FILES:
        score += Config.SCORE_PROJECT_FILE
    
    return score


def open_file(filepath: str):
    """Open file in default application"""
    try:
        if platform.system() == 'Windows':
            os.startfile(filepath)
        elif platform.system() == 'Darwin':  # macOS
            subprocess.Popen(['open', filepath])
        else:  # Linux
            subprocess.Popen(['xdg-open', filepath])
    except Exception as e:
        messagebox.showerror("Error", f"Could not open file:\n{e}")


def open_folder(folderpath: str):
    """Open folder in file explorer"""
    try:
        if platform.system() == 'Windows':
            os.startfile(folderpath)
        elif platform.system() == 'Darwin':  # macOS
            subprocess.Popen(['open', folderpath])
        else:  # Linux
            subprocess.Popen(['xdg-open', folderpath])
    except Exception as e:
        messagebox.showerror("Error", f"Could not open folder:\n{e}")


# ==================== MAIN APPLICATION ====================
class CodeFinderPro:
    """Main application class for Code Finder Pro"""
    
    def __init__(self, root):
        self.root = root
        self.root.title(f"{Config.APP_NAME} v{Config.VERSION}")
        self.root.geometry("900x750")
        
        # Application state
        self.cancel_requested = False
        self.search_thread = None
        self.results: List[Dict] = []
        self.queue = queue.Queue()
        self.preferences = self.load_preferences()
        self.search_history = self.load_history()
        
        # UI Variables
        self.root_folder = tk.StringVar(value=self.preferences.get('last_root_folder', ''))
        self.output_folder = tk.StringVar(value=self.preferences.get('last_output_folder', Config.DEFAULT_OUTPUT_DIR))
        self.keywords_var = tk.StringVar(value=self.preferences.get('last_keywords', ''))
        self.min_score_var = tk.IntVar(value=self.preferences.get('min_score', 10))
        self.copy_files_var = tk.BooleanVar(value=self.preferences.get('copy_files', True))
        self.use_regex_var = tk.BooleanVar(value=self.preferences.get('use_regex', False))
        self.max_file_size_var = tk.IntVar(value=self.preferences.get('max_file_size', 10))  # MB
        self.exclude_dirs_var = tk.StringVar(value=self.preferences.get('exclude_dirs', 'node_modules,.git,__pycache__'))
        
        # Selected file types
        self.file_type_vars = {}
        saved_types = self.preferences.get('file_types', [])
        
        # Build UI
        self.build_ui()
        
        # Restore file type selections
        if saved_types:
            for group in saved_types:
                if group in self.file_type_vars:
                    self.file_type_vars[group].set(True)
        
        # Start queue checker
        self.check_queue()
        
        # Bind close event
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
    
    def build_ui(self):
        """Build the complete user interface"""
        
        # Menu Bar
        self.create_menu()
        
        # Main container with notebook tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Tab 1: Search
        self.search_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.search_frame, text='Search')
        self.build_search_tab()
        
        # Tab 2: Advanced Settings
        self.advanced_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.advanced_frame, text='Advanced')
        self.build_advanced_tab()
        
        # Tab 3: History
        self.history_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.history_frame, text='History')
        self.build_history_tab()
        
        # Status Bar
        self.status_var = tk.StringVar(value="Ready")
        self.status_bar = ttk.Label(self.root, textvariable=self.status_var, 
                                     relief=tk.SUNKEN, anchor=tk.W)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X, padx=5, pady=2)
    
    def create_menu(self):
        """Create menu bar"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        # File Menu
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="New Search", command=self.new_search)
        file_menu.add_command(label="Export Results...", command=self.export_results)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.on_closing)
        
        # Tools Menu
        tools_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Tools", menu=tools_menu)
        tools_menu.add_command(label="Clear History", command=self.clear_history)
        tools_menu.add_command(label="Reset Preferences", command=self.reset_preferences)
        
        # Help Menu
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="Documentation", command=self.show_help)
        help_menu.add_command(label="About", command=self.show_about)
    
    def build_search_tab(self):
        """Build the main search tab"""
        
        # Folders Section
        folder_frame = ttk.LabelFrame(self.search_frame, text="Folders", padding=10)
        folder_frame.pack(fill='x', padx=10, pady=5)
        
        ttk.Label(folder_frame, text="Search Root:").grid(row=0, column=0, sticky='w', pady=5)
        ttk.Entry(folder_frame, textvariable=self.root_folder, width=60).grid(row=0, column=1, padx=5)
        ttk.Button(folder_frame, text="Browse", command=self.browse_root).grid(row=0, column=2)
        
        ttk.Label(folder_frame, text="Output Folder:").grid(row=1, column=0, sticky='w', pady=5)
        ttk.Entry(folder_frame, textvariable=self.output_folder, width=60).grid(row=1, column=1, padx=5)
        ttk.Button(folder_frame, text="Browse", command=self.browse_output).grid(row=1, column=2)
        
        ttk.Checkbutton(folder_frame, text="Copy found files to output folder", 
                       variable=self.copy_files_var).grid(row=2, column=1, sticky='w', pady=5)
        
        # File Types Section
        types_frame = ttk.LabelFrame(self.search_frame, text="File Types", padding=10)
        types_frame.pack(fill='both', expand=True, padx=10, pady=5)
        
        # Create scrollable frame for file types
        canvas = tk.Canvas(types_frame, height=150)
        scrollbar = ttk.Scrollbar(types_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Create checkbuttons for each file type group
        row, col = 0, 0
        for group, extensions in Config.FILE_TYPES.items():
            var = tk.BooleanVar()
            self.file_type_vars[group] = var
            cb = ttk.Checkbutton(scrollable_frame, text=f"{group} ({', '.join(extensions)})", 
                                variable=var)
            cb.grid(row=row, column=col, sticky='w', padx=5, pady=2)
            col += 1
            if col > 1:
                col = 0
                row += 1
        
        canvas.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        
        # Quick select buttons
        btn_frame = ttk.Frame(types_frame)
        btn_frame.pack(fill='x', pady=5)
        ttk.Button(btn_frame, text="Select All", command=self.select_all_types).pack(side='left', padx=5)
        ttk.Button(btn_frame, text="Clear All", command=self.clear_all_types).pack(side='left')
        
        # Keywords Section
        keywords_frame = ttk.LabelFrame(self.search_frame, text="Keywords", padding=10)
        keywords_frame.pack(fill='x', padx=10, pady=5)
        
        ttk.Label(keywords_frame, text="Keywords (comma-separated):").pack(anchor='w')
        ttk.Entry(keywords_frame, textvariable=self.keywords_var, width=80).pack(fill='x', pady=5)
        ttk.Checkbutton(keywords_frame, text="Use Regular Expressions", 
                       variable=self.use_regex_var).pack(anchor='w')
        
        # Score Settings
        score_frame = ttk.LabelFrame(self.search_frame, text="Score Settings", padding=10)
        score_frame.pack(fill='x', padx=10, pady=5)
        
        ttk.Label(score_frame, text="Minimum Score:").pack(side='left', padx=5)
        ttk.Scale(score_frame, from_=0, to=100, variable=self.min_score_var, 
                 orient='horizontal', length=200).pack(side='left', padx=5)
        ttk.Label(score_frame, textvariable=self.min_score_var).pack(side='left')
        
        # Action Buttons
        btn_frame = ttk.Frame(self.search_frame)
        btn_frame.pack(fill='x', padx=10, pady=10)
        
        self.run_button = tk.Button(btn_frame, text="🔍 Run Search", 
                                    command=self.run, bg=Config.COLOR_GREEN, 
                                    fg='white', font=('Arial', 12, 'bold'),
                                    padx=20, pady=10)
        self.run_button.pack(side='left', padx=5)
        
        self.cancel_button = tk.Button(btn_frame, text="✖ Cancel", 
                                       command=self.cancel_search, bg=Config.COLOR_ORANGE,
                                       fg='white', font=('Arial', 12, 'bold'),
                                       padx=20, pady=10, state='disabled')
        self.cancel_button.pack(side='left', padx=5)
        
        self.preview_button = tk.Button(btn_frame, text="👁 Preview Results", 
                                        command=self.show_preview, bg=Config.COLOR_BLUE,
                                        fg='white', font=('Arial', 12, 'bold'),
                                        padx=20, pady=10, state='disabled')
        self.preview_button.pack(side='left', padx=5)
        
        self.export_button = tk.Button(btn_frame, text="💾 Export", 
                                       command=self.export_results, bg=Config.COLOR_MAGENTA,
                                       fg='white', font=('Arial', 12, 'bold'),
                                       padx=20, pady=10, state='disabled')
        self.export_button.pack(side='left', padx=5)
    
    def build_advanced_tab(self):
        """Build advanced settings tab"""
        
        # File Size Limit
        size_frame = ttk.LabelFrame(self.advanced_frame, text="File Size Limits", padding=10)
        size_frame.pack(fill='x', padx=10, pady=10)
        
        ttk.Label(size_frame, text="Maximum File Size (MB):").pack(side='left', padx=5)
        ttk.Spinbox(size_frame, from_=1, to=100, textvariable=self.max_file_size_var,
                   width=10).pack(side='left', padx=5)
        
        # Exclude Directories
        exclude_frame = ttk.LabelFrame(self.advanced_frame, text="Exclude Directories", padding=10)
        exclude_frame.pack(fill='x', padx=10, pady=10)
        
        ttk.Label(exclude_frame, text="Directories to skip (comma-separated):").pack(anchor='w')
        ttk.Entry(exclude_frame, textvariable=self.exclude_dirs_var, width=80).pack(fill='x', pady=5)
        ttk.Label(exclude_frame, text="Example: node_modules,.git,__pycache__,venv", 
                 font=('Arial', 8, 'italic')).pack(anchor='w')
        
        # Scoring Customization
        scoring_frame = ttk.LabelFrame(self.advanced_frame, text="Scoring Weights", padding=10)
        scoring_frame.pack(fill='x', padx=10, pady=10)
        
        ttk.Label(scoring_frame, text="These settings affect how files are scored:").pack(anchor='w')
        
        weights_info = f"""
• Keyword Match: +{Config.SCORE_KEYWORD_MATCH} points
• Positive Pattern: +{Config.SCORE_POSITIVE_PATTERN} points
• Negative Pattern: {Config.SCORE_NEGATIVE_PATTERN} points
• Project File: +{Config.SCORE_PROJECT_FILE} points
        """
        ttk.Label(scoring_frame, text=weights_info, justify='left').pack(anchor='w', pady=5)
        
        # Performance Settings
        perf_frame = ttk.LabelFrame(self.advanced_frame, text="Performance", padding=10)
        perf_frame.pack(fill='x', padx=10, pady=10)
        
        ttk.Label(perf_frame, text=f"Max snippet length: {Config.MAX_SNIPPET_LENGTH} characters").pack(anchor='w')
        ttk.Label(perf_frame, text=f"Max preview content: {Config.MAX_PREVIEW_CONTENT} characters").pack(anchor='w')
    
    def build_history_tab(self):
        """Build search history tab"""
        
        # History List
        list_frame = ttk.Frame(self.history_frame)
        list_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Create treeview for history
        columns = ('date', 'keywords', 'files_found', 'root_folder')
        self.history_tree = ttk.Treeview(list_frame, columns=columns, show='headings', height=15)
        
        self.history_tree.heading('date', text='Date/Time')
        self.history_tree.heading('keywords', text='Keywords')
        self.history_tree.heading('files_found', text='Files Found')
        self.history_tree.heading('root_folder', text='Root Folder')
        
        self.history_tree.column('date', width=150)
        self.history_tree.column('keywords', width=200)
        self.history_tree.column('files_found', width=100)
        self.history_tree.column('root_folder', width=300)
        
        # Scrollbars
        vsb = ttk.Scrollbar(list_frame, orient="vertical", command=self.history_tree.yview)
        hsb = ttk.Scrollbar(list_frame, orient="horizontal", command=self.history_tree.xview)
        self.history_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        self.history_tree.grid(row=0, column=0, sticky='nsew')
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')
        
        list_frame.grid_rowconfigure(0, weight=1)
        list_frame.grid_columnconfigure(0, weight=1)
        
        # Buttons
        btn_frame = ttk.Frame(self.history_frame)
        btn_frame.pack(fill='x', padx=10, pady=5)
        
        ttk.Button(btn_frame, text="Load Selected", command=self.load_history_item).pack(side='left', padx=5)
        ttk.Button(btn_frame, text="Delete Selected", command=self.delete_history_item).pack(side='left', padx=5)
        ttk.Button(btn_frame, text="Clear All History", command=self.clear_history).pack(side='left', padx=5)
        ttk.Button(btn_frame, text="Refresh", command=self.refresh_history).pack(side='left', padx=5)
        
        # Populate history
        self.refresh_history()
    
    # ==================== FOLDER BROWSING ====================
    
    def browse_root(self):
        """Browse for root search folder"""
        folder = filedialog.askdirectory(title="Select Root Folder to Search")
        if folder:
            self.root_folder.set(folder)
    
    def browse_output(self):
        """Browse for output folder"""
        folder = filedialog.askdirectory(title="Select Output Folder")
        if folder:
            self.output_folder.set(folder)
    
    # ==================== FILE TYPE SELECTION ====================
    
    def select_all_types(self):
        """Select all file type checkboxes"""
        for var in self.file_type_vars.values():
            var.set(True)
    
    def clear_all_types(self):
        """Clear all file type checkboxes"""
        for var in self.file_type_vars.values():
            var.set(False)
    
    # ==================== SEARCH EXECUTION ====================
    
    def run(self):
        """Validate inputs and start search"""
        
        # Validation
        if not self.root_folder.get():
            messagebox.showerror("Error", "Please select a root folder to search")
            return
        
        if not os.path.exists(self.root_folder.get()):
            messagebox.showerror("Error", "Root folder does not exist")
            return
        
        if not self.output_folder.get():
            messagebox.showerror("Error", "Please select an output folder")
            return
        
        # Get selected file types
        selected_extensions = []
        for group, var in self.file_type_vars.items():
            if var.get():
                selected_extensions.extend(Config.FILE_TYPES[group])
        
        if not selected_extensions:
            messagebox.showerror("Error", "Please select at least one file type")
            return
        
        # Get keywords
        keywords_text = self.keywords_var.get().strip()
        keywords = [k.strip() for k in keywords_text.split(',') if k.strip()]
        
        if not keywords:
            result = messagebox.askyesno("No Keywords", 
                                        "No keywords specified. Search all files of selected types?")
            if not result:
                return
        
        # Create output directory
        os.makedirs(self.output_folder.get(), exist_ok=True)
        
        # Reset state
        self.cancel_requested = False
        self.results = []
        
        # Update UI
        self.run_button.config(state='disabled')
        self.cancel_button.config(state='normal')
        self.preview_button.config(state='disabled')
        self.export_button.config(state='disabled')
        self.status_var.set("Starting search...")
        
        # Start search thread
        self.search_thread = threading.Thread(
            target=self.search_worker,
            args=(selected_extensions, keywords),
            daemon=True
        )
        self.search_thread.start()
    
    def search_worker(self, extensions: List[str], keywords: List[str]):
        """Background worker for file search"""
        
        try:
            root_path = self.root_folder.get()
            output_path = self.output_folder.get()
            min_score = self.min_score_var.get()
            use_regex = self.use_regex_var.get()
            copy_files = self.copy_files_var.get()
            max_size_mb = self.max_file_size_var.get()
            max_size_bytes = max_size_mb * 1024 * 1024
            
            # Get excluded directories
            exclude_dirs = [d.strip() for d in self.exclude_dirs_var.get().split(',') if d.strip()]
            
            files_processed = 0
            files_matched = 0
            
            # Walk directory tree
            for root, dirs, files in os.walk(root_path):
                
                # Check for cancellation
                if self.cancel_requested:
                    self.queue.put(('status', 'Search cancelled'))
                    break
                
                # Filter out excluded directories
                dirs[:] = [d for d in dirs if d not in exclude_dirs]
                
                for filename in files:
                    
                    # Check for cancellation
                    if self.cancel_requested:
                        break
                    
                    # Check file extension
                    ext = os.path.splitext(filename)[1].lower()
                    if ext not in extensions:
                        continue
                    
                    filepath = os.path.join(root, filename)
                    
                    # Check file size
                    try:
                        if os.path.getsize(filepath) > max_size_bytes:
                            continue
                    except:
                        continue
                    
                    files_processed += 1
                    
                    # Update status
                    self.queue.put(('status', f"Processing: {filename} ({files_processed} files scanned, {files_matched} matched)"))
                    
                    # Extract and score content
                    content = extract_content(filepath)
                    score = score_file(content, keywords, filepath, use_regex)
                    
                    if score >= min_score:
                        files_matched += 1
                        
                        # Get matched keywords
                        matched_keywords = []
                        if content:
                            content_lower = content.lower()
                            for keyword in keywords:
                                if use_regex:
                                    try:
                                        if re.search(keyword, content, re.IGNORECASE):
                                            matched_keywords.append(keyword)
                                    except:
                                        if keyword.lower() in content_lower:
                                            matched_keywords.append(keyword)
                                else:
                                    if keyword.lower() in content_lower:
                                        matched_keywords.append(keyword)
                        
                        # Get snippet
                        snippet = content[:Config.MAX_SNIPPET_LENGTH] if content else ""
                        
                        # Prepare result
                        result = {
                            'filepath': filepath,
                            'filename': filename,
                            'extension': ext,
                            'score': score,
                            'matched_keywords': matched_keywords,
                            'snippet': snippet,
                            'size': os.path.getsize(filepath),
                            'copied_to': None
                        }
                        
                        # Copy file if requested
                        if copy_files:
                            try:
                                # Create unique filename if needed
                                dest_path = os.path.join(output_path, filename)
                                counter = 1
                                base, ext = os.path.splitext(filename)
                                while os.path.exists(dest_path):
                                    dest_path = os.path.join(output_path, f"{base}_{counter}{ext}")
                                    counter += 1
                                
                                import shutil
                                shutil.copy2(filepath, dest_path)
                                result['copied_to'] = dest_path
                            except Exception as e:
                                result['copy_error'] = str(e)
                        
                        # Add to results
                        self.results.append(result)
                        
                        # Send incremental update
                        self.queue.put(('result', result))
            
            # Sort results by score
            self.results.sort(key=lambda x: x['score'], reverse=True)
            
            # Save search to history
            self.save_to_history(keywords, files_matched)
            
            # Complete
            if self.cancel_requested:
                self.queue.put(('complete', f"Search cancelled. Found {files_matched} files in {files_processed} scanned."))
            else:
                self.queue.put(('complete', f"Search complete! Found {files_matched} matching files out of {files_processed} scanned."))
            
        except Exception as e:
            self.queue.put(('error', f"Search error: {str(e)}"))
    
    def cancel_search(self):
        """Request search cancellation"""
        self.cancel_requested = True
        self.status_var.set("Cancelling search...")
    
    def check_queue(self):
        """Check message queue from worker thread"""
        try:
            while True:
                msg_type, msg_data = self.queue.get_nowait()
                
                if msg_type == 'status':
                    self.status_var.set(msg_data)
                
                elif msg_type == 'result':
                    # Incremental result received
                    pass
                
                elif msg_type == 'complete':
                    self.status_var.set(msg_data)
                    self.run_button.config(state='normal')
                    self.cancel_button.config(state='disabled')
                    if self.results:
                        self.preview_button.config(state='normal')
                        self.export_button.config(state='normal')
                
                elif msg_type == 'error':
                    messagebox.showerror("Search Error", msg_data)
                    self.status_var.set("Search failed")
                    self.run_button.config(state='normal')
                    self.cancel_button.config(state='disabled')
        
        except queue.Empty:
            pass
        
        # Schedule next check
        self.root.after(100, self.check_queue)
    
    # ==================== PREVIEW WINDOW ====================
    
    def show_preview(self):
        """Show results preview window"""
        
        if not self.results:
            messagebox.showinfo("No Results", "No results to preview")
            return
        
        # Create preview window
        preview_win = tk.Toplevel(self.root)
        preview_win.title(f"Preview Results - {len(self.results)} files found")
        preview_win.geometry("1200x700")
        
        # Main container
        main_frame = ttk.Frame(preview_win)
        main_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Left pane - Results list
        left_frame = ttk.Frame(main_frame)
        left_frame.pack(side='left', fill='both', expand=True)
        
        ttk.Label(left_frame, text="Results (sorted by score):", font=('Arial', 10, 'bold')).pack(anchor='w')
        
        # Listbox with scrollbar
        list_frame = ttk.Frame(left_frame)
        list_frame.pack(fill='both', expand=True, pady=5)
        
        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side='right', fill='y')
        
        results_listbox = tk.Listbox(list_frame, yscrollcommand=scrollbar.set, 
                                     font=('Courier', 9), width=50)
        results_listbox.pack(side='left', fill='both', expand=True)
        scrollbar.config(command=results_listbox.yview)
        
        # Populate listbox
        for idx, result in enumerate(self.results, 1):
            display_text = f"#{idx:3d} | Score: {result['score']:3d} | {result['filename']}"
            results_listbox.insert(tk.END, display_text)
        
        # Right pane - Details
        right_frame = ttk.Frame(main_frame)
        right_frame.pack(side='right', fill='both', expand=True, padx=(10, 0))
        
        ttk.Label(right_frame, text="File Details:", font=('Arial', 10, 'bold')).pack(anchor='w')
        
        details_text = scrolledtext.ScrolledText(right_frame, wrap='word', width=60, height=30)
        details_text.pack(fill='both', expand=True, pady=5)
        
        # Action buttons frame
        btn_frame = ttk.Frame(right_frame)
        btn_frame.pack(fill='x', pady=5)
        
        selected_filepath = [None]  # Mutable container for closure
        
        def update_details(event=None):
            """Update details pane with selected result"""
            selection = results_listbox.curselection()
            if not selection:
                return
            
            idx = selection[0]
            result = self.results[idx]
            selected_filepath[0] = result['filepath']
            
            # Build details text
            details = f"""FILE INFORMATION
{'=' * 80}
Rank: #{idx + 1} of {len(self.results)}
Score: {result['score']}
File: {result['filename']}
Path: {result['filepath']}
Extension: {result['extension']}
Size: {result['size']:,} bytes

MATCHED KEYWORDS
{'=' * 80}
{', '.join(result['matched_keywords']) if result['matched_keywords'] else 'None'}

COPIED TO
{'=' * 80}
{result.get('copied_to', 'Not copied')}

CONTENT SNIPPET
{'=' * 80}
{result['snippet']}
"""
            
            details_text.delete('1.0', tk.END)
            details_text.insert('1.0', details)
        
        def open_selected_file():
            """Open the selected file"""
            if selected_filepath[0]:
                open_file(selected_filepath[0])
        
        def open_selected_folder():
            """Open folder containing selected file"""
            if selected_filepath[0]:
                folder = os.path.dirname(selected_filepath[0])
                open_folder(folder)
        
        # Bind selection event
        results_listbox.bind('<<ListboxSelect>>', update_details)
        
        # Action buttons
        ttk.Button(btn_frame, text="📂 Open File", command=open_selected_file).pack(side='left', padx=2)
        ttk.Button(btn_frame, text="📁 Open Folder", command=open_selected_folder).pack(side='left', padx=2)
        
        # Select first item
        if results_listbox.size() > 0:
            results_listbox.selection_set(0)
            update_details()
    
    # ==================== EXPORT ====================
    
    def export_results(self):
        """Export results to various formats"""
        
        if not self.results:
            messagebox.showinfo("No Results", "No results to export")
            return
        
        # Ask for format
        export_win = tk.Toplevel(self.root)
        export_win.title("Export Results")
        export_win.geometry("400x200")
        export_win.transient(self.root)
        export_win.grab_set()
        
        ttk.Label(export_win, text="Select export format:", 
                 font=('Arial', 12)).pack(pady=20)
        
        format_var = tk.StringVar(value="json")
        
        ttk.Radiobutton(export_win, text="JSON (JavaScript Object Notation)", 
                       variable=format_var, value="json").pack(anchor='w', padx=40)
        ttk.Radiobutton(export_win, text="CSV (Comma-Separated Values)", 
                       variable=format_var, value="csv").pack(anchor='w', padx=40)
        ttk.Radiobutton(export_win, text="TXT (Plain Text Report)", 
                       variable=format_var, value="txt").pack(anchor='w', padx=40)
        
        def do_export():
            format_type = format_var.get()
            export_win.destroy()
            
            # Get save filename
            filetypes = {
                'json': [("JSON files", "*.json")],
                'csv': [("CSV files", "*.csv")],
                'txt': [("Text files", "*.txt")]
            }
            
            filename = filedialog.asksaveasfilename(
                defaultextension=f".{format_type}",
                filetypes=filetypes[format_type],
                initialfile=f"code_finder_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.{format_type}"
            )
            
            if not filename:
                return
            
            try:
                if format_type == 'json':
                    self.export_json(filename)
                elif format_type == 'csv':
                    self.export_csv(filename)
                elif format_type == 'txt':
                    self.export_txt(filename)
                
                messagebox.showinfo("Export Complete", f"Results exported to:\n{filename}")
                
            except Exception as e:
                messagebox.showerror("Export Error", f"Failed to export:\n{str(e)}")
        
        ttk.Button(export_win, text="Export", command=do_export).pack(pady=20)
    
    def export_json(self, filename: str):
        """Export results to JSON"""
        export_data = {
            'export_date': datetime.now().isoformat(),
            'app_version': Config.VERSION,
            'search_parameters': {
                'root_folder': self.root_folder.get(),
                'keywords': self.keywords_var.get(),
                'min_score': self.min_score_var.get(),
                'use_regex': self.use_regex_var.get()
            },
            'results_count': len(self.results),
            'results': self.results
        }
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, indent=2, ensure_ascii=False)
    
    def export_csv(self, filename: str):
        """Export results to CSV"""
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            
            # Header
            writer.writerow(['Rank', 'Score', 'Filename', 'Filepath', 'Extension', 
                           'Size', 'Matched Keywords', 'Copied To'])
            
            # Data
            for idx, result in enumerate(self.results, 1):
                writer.writerow([
                    idx,
                    result['score'],
                    result['filename'],
                    result['filepath'],
                    result['extension'],
                    result['size'],
                    ', '.join(result['matched_keywords']),
                    result.get('copied_to', '')
                ])
    
    def export_txt(self, filename: str):
        """Export results to plain text report"""
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(f"{Config.APP_NAME} - Search Results Report\n")
            f.write(f"{'=' * 80}\n\n")
            f.write(f"Export Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Root Folder: {self.root_folder.get()}\n")
            f.write(f"Keywords: {self.keywords_var.get()}\n")
            f.write(f"Minimum Score: {self.min_score_var.get()}\n")
            f.write(f"Total Results: {len(self.results)}\n\n")
            f.write(f"{'=' * 80}\n\n")
            
            for idx, result in enumerate(self.results, 1):
                f.write(f"RESULT #{idx}\n")
                f.write(f"{'-' * 80}\n")
                f.write(f"Score: {result['score']}\n")
                f.write(f"File: {result['filename']}\n")
                f.write(f"Path: {result['filepath']}\n")
                f.write(f"Size: {result['size']:,} bytes\n")
                f.write(f"Keywords: {', '.join(result['matched_keywords'])}\n")
                if result.get('copied_to'):
                    f.write(f"Copied To: {result['copied_to']}\n")
                f.write(f"\nSnippet:\n{result['snippet']}\n\n")
                f.write(f"{'=' * 80}\n\n")
    
    # ==================== HISTORY MANAGEMENT ====================
    
    def load_history(self) -> List[Dict]:
        """Load search history from file"""
        ensure_config_dir()
        try:
            if os.path.exists(Config.HISTORY_FILE):
                with open(Config.HISTORY_FILE, 'r') as f:
                    return json.load(f)
        except:
            pass
        return []
    
    def save_to_history(self, keywords: List[str], files_found: int):
        """Save current search to history"""
        history_item = {
            'timestamp': datetime.now().isoformat(),
            'keywords': ', '.join(keywords),
            'files_found': files_found,
            'root_folder': self.root_folder.get(),
            'output_folder': self.output_folder.get(),
            'min_score': self.min_score_var.get(),
            'use_regex': self.use_regex_var.get(),
            'file_types': [group for group, var in self.file_type_vars.items() if var.get()]
        }
        
        self.search_history.insert(0, history_item)
        
        # Limit history size
        if len(self.search_history) > Config.MAX_HISTORY_ITEMS:
            self.search_history = self.search_history[:Config.MAX_HISTORY_ITEMS]
        
        # Save to file
        ensure_config_dir()
        try:
            with open(Config.HISTORY_FILE, 'w') as f:
                json.dump(self.search_history, f, indent=2)
        except Exception as e:
            print(f"Failed to save history: {e}")
    
    def refresh_history(self):
        """Refresh history display"""
        # Clear tree
        for item in self.history_tree.get_children():
            self.history_tree.delete(item)
        
        # Populate
        for item in self.search_history:
            dt = datetime.fromisoformat(item['timestamp'])
            date_str = dt.strftime('%Y-%m-%d %H:%M')
            
            self.history_tree.insert('', 'end', values=(
                date_str,
                item['keywords'],
                item['files_found'],
                item['root_folder']
            ))
    
    def load_history_item(self):
        """Load selected history item into search form"""
        selection = self.history_tree.selection()
        if not selection:
            messagebox.showinfo("No Selection", "Please select a history item to load")
            return
        
        # Get selected index
        item = selection[0]
        idx = self.history_tree.index(item)
        history_item = self.search_history[idx]
        
        # Load into form
        self.root_folder.set(history_item['root_folder'])
        self.output_folder.set(history_item['output_folder'])
        self.keywords_var.set(history_item['keywords'])
        self.min_score_var.set(history_item['min_score'])
        self.use_regex_var.set(history_item.get('use_regex', False))
        
        # Load file types
        self.clear_all_types()
        for group in history_item.get('file_types', []):
            if group in self.file_type_vars:
                self.file_type_vars[group].set(True)
        
        # Switch to search tab
        self.notebook.select(0)
        
        messagebox.showinfo("History Loaded", "Search parameters loaded from history")
    
    def delete_history_item(self):
        """Delete selected history item"""
        selection = self.history_tree.selection()
        if not selection:
            messagebox.showinfo("No Selection", "Please select a history item to delete")
            return
        
        result = messagebox.askyesno("Confirm Delete", "Delete selected history item?")
        if not result:
            return
        
        # Get selected index and delete
        item = selection[0]
        idx = self.history_tree.index(item)
        del self.search_history[idx]
        
        # Save and refresh
        ensure_config_dir()
        with open(Config.HISTORY_FILE, 'w') as f:
            json.dump(self.search_history, f, indent=2)
        
        self.refresh_history()
    
    def clear_history(self):
        """Clear all search history"""
        result = messagebox.askyesno("Confirm Clear", 
                                     "Clear all search history? This cannot be undone.")
        if not result:
            return
        
        self.search_history = []
        ensure_config_dir()
        with open(Config.HISTORY_FILE, 'w') as f:
            json.dump([], f)
        
        self.refresh_history()
        messagebox.showinfo("History Cleared", "All search history has been cleared")
    
    # ==================== PREFERENCES ====================
    
    def load_preferences(self) -> Dict:
        """Load user preferences from file"""
        ensure_config_dir()
        try:
            if os.path.exists(Config.CONFIG_FILE):
                with open(Config.CONFIG_FILE, 'r') as f:
                    return json.load(f)
        except:
            pass
        return {}
    
    def save_preferences(self):
        """Save current preferences"""
        prefs = {
            'last_root_folder': self.root_folder.get(),
            'last_output_folder': self.output_folder.get(),
            'last_keywords': self.keywords_var.get(),
            'min_score': self.min_score_var.get(),
            'copy_files': self.copy_files_var.get(),
            'use_regex': self.use_regex_var.get(),
            'max_file_size': self.max_file_size_var.get(),
            'exclude_dirs': self.exclude_dirs_var.get(),
            'file_types': [group for group, var in self.file_type_vars.items() if var.get()]
        }
        
        ensure_config_dir()
        try:
            with open(Config.CONFIG_FILE, 'w') as f:
                json.dump(prefs, f, indent=2)
        except Exception as e:
            print(f"Failed to save preferences: {e}")
    
    def reset_preferences(self):
        """Reset preferences to defaults"""
        result = messagebox.askyesno("Confirm Reset", 
                                     "Reset all preferences to defaults?")
        if not result:
            return
        
        self.root_folder.set('')
        self.output_folder.set(Config.DEFAULT_OUTPUT_DIR)
        self.keywords_var.set('')
        self.min_score_var.set(10)
        self.copy_files_var.set(True)
        self.use_regex_var.set(False)
        self.max_file_size_var.set(10)
        self.exclude_dirs_var.set('node_modules,.git,__pycache__')
        self.clear_all_types()
        
        self.save_preferences()
        messagebox.showinfo("Preferences Reset", "All preferences have been reset to defaults")
    
    # ==================== MENU ACTIONS ====================
    
    def new_search(self):
        """Start a new search"""
        self.results = []
        self.preview_button.config(state='disabled')
        self.export_button.config(state='disabled')
        self.status_var.set("Ready for new search")
        self.notebook.select(0)
    
    def show_help(self):
        """Show help documentation"""
        help_text = f"""
{Config.APP_NAME} - Help Documentation

OVERVIEW
Code Finder Pro is a powerful tool for searching and analyzing code across
large directory structures. It helps you find relevant files based on keywords,
file types, and intelligent scoring.

BASIC USAGE
1. Select a root folder to search
2. Choose an output folder for results
3. Select file types you want to search
4. Enter keywords (comma-separated)
5. Set minimum score threshold
6. Click "Run Search"

SCORING SYSTEM
Files are scored based on:
• Keyword matches: +{Config.SCORE_KEYWORD_MATCH} points each
• Positive patterns (function, class, etc.): +{Config.SCORE_POSITIVE_PATTERN} points
• Negative patterns (error, todo, etc.): {Config.SCORE_NEGATIVE_PATTERN} points
• Project files (package.json, etc.): +{Config.SCORE_PROJECT_FILE} points

ADVANCED FEATURES
• Regular Expression support for advanced keyword matching
• File size limits to skip large files
• Directory exclusion to skip folders like node_modules
• Search history to revisit previous searches
• Export results to JSON, CSV, or TXT formats

KEYBOARD SHORTCUTS
• Ctrl+N: New search
• Ctrl+E: Export results
• Ctrl+H: Show this help

For more information, visit: www.omegaui.com/codefinderpro
        """
        
        help_win = tk.Toplevel(self.root)
        help_win.title("Help")
        help_win.geometry("700x600")
        
        text = scrolledtext.ScrolledText(help_win, wrap='word', padx=10, pady=10)
        text.pack(fill='both', expand=True)
        text.insert('1.0', help_text)
        text.config(state='disabled')
        
        ttk.Button(help_win, text="Close", command=help_win.destroy).pack(pady=10)
    
    def show_about(self):
        """Show about dialog"""
        about_text = f"""
{Config.APP_NAME}
Version {Config.VERSION}

{Config.COPYRIGHT}

A professional code search and analysis tool for developers,
built with Python and tkinter.

Part of the Cloud Connect suite of developer tools.

Website: www.omegaui.com
Email: info@omegaui.com
Phone: +1 239-347-6030

This software is patent-pending technology.
USPTO Application: 63942196 (B.R.A.D.Y./UCP Systems)
        """
        
        about_win = tk.Toplevel(self.root)
        about_win.title(f"About {Config.APP_NAME}")
        about_win.geometry("500x400")
        about_win.resizable(False, False)
        
        # Logo/Title frame with brand color
        title_frame = tk.Frame(about_win, bg=Config.COLOR_MAGENTA, height=80)
        title_frame.pack(fill='x')
        title_frame.pack_propagate(False)
        
        tk.Label(title_frame, text=Config.APP_NAME, 
                font=('Arial', 24, 'bold'), bg=Config.COLOR_MAGENTA, 
                fg='white').pack(expand=True)
        
        # About text
        text_frame = ttk.Frame(about_win)
        text_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        tk.Label(text_frame, text=about_text, justify='center', 
                font=('Arial', 10)).pack(expand=True)
        
        # Buttons
        btn_frame = ttk.Frame(about_win)
        btn_frame.pack(fill='x', padx=20, pady=10)
        
        def open_website():
            webbrowser.open("https://www.omegaui.com")
        
        ttk.Button(btn_frame, text="Visit Website", command=open_website).pack(side='left', padx=5)
        ttk.Button(btn_frame, text="Close", command=about_win.destroy).pack(side='right', padx=5)
    
    # ==================== CLEANUP ====================
    
    def on_closing(self):
        """Handle window close event"""
        # Save preferences
        self.save_preferences()
        
        # Cancel any running search
        if self.search_thread and self.search_thread.is_alive():
            result = messagebox.askyesno("Search in Progress", 
                                        "A search is currently running. Cancel and exit?")
            if not result:
                return
            self.cancel_requested = True
            self.search_thread.join(timeout=2)
        
        self.root.destroy()


# ==================== MAIN ENTRY POINT ====================
def main():
    """Main entry point for the application"""
    root = tk.Tk()
    app = CodeFinderPro(root)
    root.mainloop()


if __name__ == "__main__":
    main()
