#!/usr/bin/env python3
"""
Build Script for Code Finder Pro
Creates standalone executable using PyInstaller

Copyright © 2026 Omega UI, LLC / Cloud Connect
"""

import subprocess
import sys
import os
from pathlib import Path

def check_pyinstaller():
    """Check if PyInstaller is installed"""
    try:
        import PyInstaller
        return True
    except ImportError:
        return False

def install_pyinstaller():
    """Install PyInstaller"""
    print("PyInstaller not found. Installing...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
        print("✓ PyInstaller installed successfully")
        return True
    except subprocess.CalledProcessError:
        print("✗ Failed to install PyInstaller")
        return False

def build_executable():
    """Build standalone executable"""
    print("\n" + "="*60)
    print("Code Finder Pro - Build Script")
    print("="*60 + "\n")
    
    # Check PyInstaller
    if not check_pyinstaller():
        if not install_pyinstaller():
            print("\nBuild failed: Could not install PyInstaller")
            return False
    
    # Build command
    print("Building executable...")
    print("This may take a few minutes...\n")
    
    cmd = [
        "pyinstaller",
        "--name=CodeFinderPro",
        "--onefile",  # Single executable file
        "--windowed",  # No console window (GUI only)
        "--icon=NONE",  # Add icon file if available
        "--add-data=README.md:.",  # Include README
        "code_finder_pro.py"
    ]
    
    try:
        subprocess.check_call(cmd)
        print("\n" + "="*60)
        print("✓ Build Successful!")
        print("="*60)
        print("\nExecutable location:")
        print(f"  {Path('dist/CodeFinderPro.exe' if sys.platform == 'win32' else 'dist/CodeFinderPro')}")
        print("\nYou can now distribute this file as a standalone application.")
        print("No Python installation required on target machines!")
        return True
        
    except subprocess.CalledProcessError as e:
        print("\n" + "="*60)
        print("✗ Build Failed")
        print("="*60)
        print(f"\nError: {e}")
        return False

def clean_build_files():
    """Clean up build artifacts"""
    import shutil
    
    dirs_to_remove = ['build', '__pycache__']
    files_to_remove = ['CodeFinderPro.spec']
    
    print("\nCleaning up build files...")
    
    for dir_name in dirs_to_remove:
        if os.path.exists(dir_name):
            shutil.rmtree(dir_name)
            print(f"  Removed: {dir_name}/")
    
    for file_name in files_to_remove:
        if os.path.exists(file_name):
            os.remove(file_name)
            print(f"  Removed: {file_name}")
    
    print("✓ Cleanup complete\n")

if __name__ == "__main__":
    success = build_executable()
    
    if success:
        clean = input("\nClean up build files? (y/n): ").lower().strip()
        if clean == 'y':
            clean_build_files()
        
        print("\n" + "="*60)
        print("Build process complete!")
        print("="*60 + "\n")
    else:
        print("\nBuild process failed. Please check the errors above.\n")
        sys.exit(1)
